package com.example.cecyt9.pasodevariables;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.EditText;
import android.widget.TextView;

public class inicio extends AppCompatActivity {

    TextView lblUsur;
    EditText lblUrl;
    WebView miChrome;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio);
        lblUsur=(TextView) findViewById(R.id.lblUsuario);

        lblUrl=(EditText) findViewById(R.id.txtUrl);

        Intent intento2= getIntent();

        String nombreUsr=intento2.getExtras().getString("nombreUsr").toString();

        lblUsur.setText(lblUsur.getText().toString()+nombreUsr);
    }
}
