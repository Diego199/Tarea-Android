package com.example.cecyt9.pasodevariables;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText txtUsuario, txtContra;
    TextView lblMsj;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtUsuario=(EditText)findViewById(R.id.txtNombre);
        txtContra=(EditText)findViewById(R.id.txtPsw);
        lblMsj=(TextView) findViewById(R.id.txtMsj);
    }

    public void entrar(View laVistaXML){

        String usr="llamadadelwsalabasededatos";
        int idUsuario=15;

        if(txtUsuario.getText().toString().equals("XD") && txtContra.getText().toString().equals("123")){
            Intent miIntento= new Intent(this, inicio.class);
            miIntento.putExtra("idUsr", idUsuario);
            miIntento.putExtra("nombreUsr", usr);
            startActivity(miIntento);
        }
        else{
            String msj="usr invalido";
            lblMsj.setText(msj);
        }
    }
}
